# InsightAI — Versão 1 (parte 1): Esqueleto + CRUDs

Este documento explica **como e por que** cada parte do código funciona.
A ideia não é só "ter o código", mas entender a lógica por trás de cada
decisão, já que esse projeto é um estudo.

---

## 1. Visão geral do que foi construído

Construímos o **backend** (API) da Versão 1, cobrindo:

- Esqueleto de uma API REST em Node.js + Express
- Conexão com PostgreSQL
- CRUD completo de **Usuários**, **Projetos** e **Datasets**
- Upload de arquivos (CSV/JSON/Excel) associados a um dataset
- Cadastro/login básico com senha criptografada (hash)
- Ambiente containerizado com Docker + Docker Compose

**O que ficou de fora de propósito** (fica para as próximas etapas):
- Frontend em React
- JWT / autenticação por token (Versão 5)
- Dashboard visual
- Análises automáticas dos dados (Versão 2)

Isso porque você pediu para focar só no esqueleto + CRUDs primeiro — faz
sentido dominar essa base antes de empilhar autenticação e IA em cima.

---

## 2. Por que a arquitetura é dividida em camadas (MVC)?

```
Rota (routes/)  →  Controller (controllers/)  →  Model (models/)  →  Banco
```

Cada camada tem **uma única responsabilidade**:

| Camada | Pergunta que ela responde | O que NUNCA deveria conter |
|---|---|---|
| **Routes** | "Qual função trata essa URL + verbo HTTP?" | Lógica de negócio, SQL |
| **Controllers** | "O que fazer com os dados da requisição?" | SQL puro |
| **Models** | "Como buscar/gravar isso no banco?" | Coisas de HTTP (req/res) |

**Por que separar assim?**
Se um dia você trocar o Postgres por outro banco, só o `models/` muda.
Se um dia você trocar Express por outro framework HTTP, só `routes/` e
parte de `controllers/` mudam. Cada peça pode evoluir sem quebrar as
outras — isso é o próprio conceito de *baixo acoplamento*.

---

## 3. O fluxo de uma requisição, passo a passo

Exemplo: `POST /api/projects` criando um projeto novo.

1. **`server.js`** recebe a requisição HTTP bruta. O middleware
   `express.json()` já converte o corpo (JSON) da requisição em um
   objeto JavaScript acessível como `req.body`.
2. O Express olha a URL (`/api/projects`) e delega para
   **`routes/projectRoutes.js`**, que mapeia `POST /` para
   `projectController.createProject`.
3. O **Controller** (`projectController.js`) extrai `userId`, `name`,
   `description` de `req.body`, valida se os campos obrigatórios vieram,
   e chama `projectModel.create(...)`.
4. O **Model** (`projectModel.js`) monta e executa a query SQL:
   ```sql
   INSERT INTO projects (user_id, name, description) VALUES ($1, $2, $3)
   ```
   Repare no uso de `$1, $2, $3` (query parametrizada) em vez de montar a
   string SQL concatenando variáveis. Isso é essencial: evita **SQL
   Injection**, porque a biblioteca `pg` trata os valores como dados
   puros, nunca como parte do comando SQL.
5. O Postgres executa o INSERT e devolve a linha criada (`RETURNING ...`).
6. O Model devolve esse objeto para o Controller.
7. O Controller responde `res.status(201).json(project)` — `201` é o
   código HTTP correto para "recurso criado com sucesso".

Esse mesmo fluxo se repete (com variações) para GET, PUT e DELETE de
cada recurso.

---

## 4. Por que usamos um "Pool" de conexões (`config/db.js`)?

Abrir uma conexão nova com o banco a cada requisição é caro (tempo de
rede + autenticação). O `Pool` do `pg` mantém um conjunto de conexões já
abertas e as reaproveita: quando uma query termina, a conexão volta para
o pool em vez de ser fechada, pronta para a próxima requisição usar.
Isso é o que permite a API atender múltiplas requisições simultâneas com
boa performance.

---

## 5. Modelagem do banco de dados (`sql/init.sql`)

```
users (1) ──< (N) projects (1) ──< (N) datasets
```

- Um **usuário** pode ter vários **projetos** (`projects.user_id` é uma
  chave estrangeira para `users.id`).
- Um **projeto** pode ter vários **datasets** (`datasets.project_id` é
  uma chave estrangeira para `projects.id`).

**`ON DELETE CASCADE`**: se um usuário for deletado, o banco
automaticamente apaga seus projetos (e os datasets desses projetos)
também. Isso evita "registros órfãos" (um projeto apontando para um
`user_id` que não existe mais) sem precisarmos escrever esse código
manualmente na aplicação — o banco garante essa regra por conta própria.

**Índices (`CREATE INDEX`)**: como frequentemente vamos filtrar
"projetos de um usuário X" ou "datasets de um projeto Y", criamos índices
nessas colunas de chave estrangeira. Isso faz o Postgres localizar essas
linhas muito mais rápido do que teria de varrer a tabela inteira.

---

## 6. Senhas: por que hash e não texto puro?

No `userController.js`:
```js
const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
```
(usamos a lib `bcryptjs` — uma implementação 100% em JavaScript do bcrypt,
sem partes nativas compiladas. Isso evita erros de "arquitetura errada"
como o `Exec format error` que pode acontecer com o `bcrypt` original
quando o `node_modules` do host acaba sendo copiado para dentro do
container, por exemplo.)

Se o banco de dados vazar um dia, senhas em texto puro seriam expostas
diretamente. Com **hash** (bcrypt), o que fica salvo é uma sequência
irreversível derivada da senha — não dá para "descriptografar" de volta.

No login, comparamos assim:
```js
const passwordMatches = await bcrypt.compare(password, user.password_hash);
```
Isso recalcula o hash da senha digitada (usando o mesmo salt embutido no
hash salvo) e compara os hashes — nunca comparamos a senha em texto puro
com nada.

`SALT_ROUNDS = 10` define quantas vezes o algoritmo "embaralha" os dados
internamente. Quanto maior, mais lento e mais resistente a ataques de
força bruta (mas também mais lento para processar).

---

## 7. Upload de arquivos (Multer)

Fluxo do `POST /api/datasets`:

```
Requisição multipart/form-data
        │
   multer (middleware)  → salva o arquivo em /src/uploads com nome único
        │
   req.file preenchido (nome, caminho, tamanho, tipo)
        │
   datasetController.createDataset
        │
   datasetModel.create()  → salva METADADOS no banco (não o arquivo em si)
```

Duas decisões importantes aqui:

1. **O arquivo fica no disco, não no banco.** Bancos relacionais não são
   feitos para guardar arquivos grandes como blobs — isso deixaria o
   banco pesado e lento. Por isso guardamos só o *caminho* do arquivo
   (`file_path`) no banco, e o conteúdo real fica em `/src/uploads`.
2. **Nome único gerado (`stored_filename`)** evita que dois uploads com
   o mesmo nome de arquivo original (ex: `dados.csv` enviado por dois
   usuários diferentes) se sobrescrevam no disco.

No `docker-compose.yml`, a pasta de uploads foi mapeada como um
**volume nomeado** (`insightai_uploads`), então os arquivos sobrevivem
mesmo se o container for recriado.

---

## 8. Tratamento de erros centralizado

Em vez de repetir `try/catch` com lógica de resposta de erro em cada
controller, usamos o padrão do Express: qualquer controller que capturar
um erro inesperado chama `next(err)`, e isso desvia a requisição
diretamente para o `errorHandler.js` — o **último** middleware
registrado em `server.js`. Erros esperados (ex: "usuário não encontrado",
código 404) continuam sendo tratados no próprio controller, porque eles
não são "erros de sistema", são respostas de negócio válidas.

Detalhe interessante: capturamos códigos de erro específicos do
Postgres, como:
- `23505` → violação de `UNIQUE` (ex: email duplicado)
- `23503` → violação de `FOREIGN KEY` (ex: criar projeto com um
  `userId` que não existe)

Isso permite devolver mensagens de erro específicas e úteis (`409
Conflict`, `400 Bad Request`) em vez de um genérico "erro interno" (500)
para situações que na verdade são erros de validação do usuário.

---

## 9. Docker: por que dois serviços separados (`db` e `backend`)?

```
docker-compose.yml
 ├── db       → container só do PostgreSQL
 └── backend  → container só da API Node.js
```

Separar em containers diferentes segue o princípio de "um processo por
container": cada serviço pode ser reiniciado, escalado ou substituído
independentemente. O `depends_on` com `condition: service_healthy`
garante que o backend só sobe **depois** que o Postgres já está pronto
para aceitar conexões (evita o erro clássico de "a API subiu mas o banco
ainda não estava pronto").

O arquivo `sql/init.sql` é montado como volume em
`/docker-entrypoint-initdb.d/` — essa é uma convenção da imagem oficial
do Postgres: qualquer script `.sql` colocado ali é executado
**automaticamente**, mas só na primeira vez que o volume de dados é
criado (ou seja, se você já tem dados salvos, ele não vai rodar de novo
e apagar nada).

---

## 10. Como rodar o projeto

**Opção 1 — com Docker (recomendado):**
```bash
docker compose up --build
```
Isso sobe o Postgres e a API juntos. A API fica disponível em
`http://localhost:3000`.

**Opção 2 — rodando localmente (sem Docker):**
```bash
npm install
cp .env.example .env   # ajuste DB_HOST=localhost se o Postgres não estiver em Docker
npm run dev
```
Nesse caso você precisa ter um PostgreSQL rodando localmente e executar
o `sql/init.sql` manualmente nele.

---

## 11. Testando os endpoints (exemplos)

```bash
# Health check
curl http://localhost:3000/health

# Criar usuário
curl -X POST http://localhost:3000/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Ana","email":"ana@teste.com","password":"123456"}'

# Login
curl -X POST http://localhost:3000/api/users/login \
  -H "Content-Type: application/json" \
  -d '{"email":"ana@teste.com","password":"123456"}'

# Criar projeto (userId=1 supondo que o usuário criado acima tem id 1)
curl -X POST http://localhost:3000/api/projects \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"name":"Vendas 2026","description":"Análise de vendas"}'

# Upload de dataset (projectId=1 supondo o projeto criado acima)
curl -X POST http://localhost:3000/api/datasets \
  -F "projectId=1" \
  -F "name=Vendas Jan" \
  -F "file=@/caminho/para/vendas.csv"

# Listar datasets de um projeto
curl "http://localhost:3000/api/datasets?projectId=1"
```

---

## 12. Endpoints disponíveis (resumo)

| Recurso | Método | Rota | Descrição |
|---|---|---|---|
| Usuários | POST | `/api/users` | Cadastro |
| Usuários | POST | `/api/users/login` | Login |
| Usuários | GET | `/api/users` | Listar todos |
| Usuários | GET | `/api/users/:id` | Buscar um |
| Usuários | PUT | `/api/users/:id` | Atualizar |
| Usuários | DELETE | `/api/users/:id` | Remover |
| Projetos | POST | `/api/projects` | Criar |
| Projetos | GET | `/api/projects?userId=` | Listar (filtro opcional) |
| Projetos | GET | `/api/projects/:id` | Buscar um |
| Projetos | PUT | `/api/projects/:id` | Atualizar |
| Projetos | DELETE | `/api/projects/:id` | Remover |
| Datasets | POST | `/api/datasets` | Upload (multipart/form-data) |
| Datasets | GET | `/api/datasets?projectId=` | Listar (filtro opcional) |
| Datasets | GET | `/api/datasets/:id` | Buscar um |
| Datasets | PUT | `/api/datasets/:id` | Renomear |
| Datasets | DELETE | `/api/datasets/:id` | Remover (banco + arquivo físico) |

---

## 13. Próximos passos sugeridos

Seguindo o roadmap do projeto, os próximos incrementos naturais seriam:

1. **Frontend em React** consumindo esses mesmos endpoints (telas de
   login, lista de projetos, upload de dataset).
2. **JWT** no login, para autenticar as próximas requisições sem
   precisar reenviar email/senha o tempo todo.
3. **Validação mais robusta** de entrada (ex: usar uma lib como `zod` ou
   `joi` em vez de checagens manuais de `if (!campo)`).
4. Migrar as queries SQL manuais para uma ferramenta de **migrations**
   (ex: `node-pg-migrate`), para versionar mudanças no schema do banco
   ao longo do tempo, em vez de um único `init.sql`.

Qualquer um desses é um bom próximo passo para continuar a Versão 1 ou
já avançar para as versões seguintes do roadmap.
